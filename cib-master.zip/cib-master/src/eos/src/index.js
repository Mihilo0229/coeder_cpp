window.eosjs = require('eosjs')
